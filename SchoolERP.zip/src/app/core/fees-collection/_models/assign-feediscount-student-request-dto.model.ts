import { AssignFeesStudentModel } from '..';

export class AssignFeediscountStudentRequestDtoModel {

    feeDiscountId: number;
    studentDtos: AssignFeesStudentModel[];

    // clear() {
        
    //     this.feeGroupId= 0;
    //     this.feeGroupName= '';
    //     this.studentDtos = [];

    // }
}