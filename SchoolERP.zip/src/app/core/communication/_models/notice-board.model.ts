export class NoticeBoardModel {

    title: string;
    message: string;
    messageTo: string;
    id: number;
    isActive: string;
    noticeDate: string;
    publishOn: string;
   
    clear() {
    
        this.title= '';
        this.message= '';
        this.messageTo= '';
        this.id= 0;
        this.isActive= '';
        this.noticeDate= '';
        this.noticeDate= '';
        
    }
}